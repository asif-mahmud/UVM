#include "usbdemo.h"
#include <stdint.h>

int init_usb()
{
	int ret;
	usb_init();
	/* compute VID/PID from usbconfig.h so that there is a central source of information */
    vid = rawVid[1] * 256 + rawVid[0];
    pid = rawPid[1] * 256 + rawPid[0];
    /* The following function is in opendevice.c: */
    if((ret=usbOpenDevice(&handle, vid, vendor, pid, product, NULL, NULL, NULL)) != 0){
        //fprintf(stderr, "Could not find USB device \"%s\" with vid=0x%x pid=0x%x\n", product, vid, pid);
		
		
        return (ret+256);
    }
	return 0;
}


int test(unsigned val)
{
	int r = init_usb();
	if(r==0)
	{
		cnt = usb_control_msg(handle, USB_TYPE_VENDOR | USB_RECIP_DEVICE | USB_ENDPOINT_IN, CUSTOM_RQ_ECHO, val, 0, _test, sizeof(_test), 5000);
		unsigned temp;
		if(cnt < 1){
				return 260;/*test error*/
			}
		else
			{
				temp = _test[0]&0xff;
				temp<<=8;
				temp|= _test[1];
				temp<<=8;
				temp|= _test[2];
				temp<<=8;
				temp|= _test[3];
				if(temp!=val)
				{
					fprintf(stdout,"\nNot matched!\nfound :%d\n%s\n",temp,buffer);
					return 260;
				}
			}
	}
	else
		return r;
	return 0;/*test success*/
}


int read_adc()
{
	int r = init_usb();
	int_8 adc_value;
	if(r==0)
	{
		cnt = usb_control_msg(handle, USB_TYPE_VENDOR | USB_RECIP_DEVICE | USB_ENDPOINT_IN, CUSTOM_RQ_GET_STATUS, 0, 0, buffer, sizeof(buffer), 5000);

		if(cnt < 1){
				return 1029;/*read adc error*/
			}
		else
		{
			adc_value = 0;
			
			adc_value = buffer[0];
			
			
			//fprintf(stdout,"\n%u\n",adc_value);
			return adc_value;
		}
	}
	else
		return r;
	
	return 0;
}

int set_load_cfg(unsigned char willMonitorLoad/*=0 doesnt monitor & =1 monitors load*/,
					unsigned char startValue/*must be adc value(0-255)*/,
					unsigned char stopValue/*must be adc value(0-255)*/)
{
	unsigned char cfg_buffer[3] ;
	cfg_buffer[0] = willMonitorLoad;
	cfg_buffer[1] = startValue;
	cfg_buffer[2] = stopValue;
	
    unsigned val = stopValue;
    val=(val<<8);
	val|=startValue;
	
	
	int r = init_usb();
	if(r==0)
	{
		usb_control_msg(handle, USB_TYPE_VENDOR | USB_RECIP_DEVICE | USB_ENDPOINT_OUT, CUSTOM_RQ_SET_STATUS, val,willMonitorLoad, cfg_buffer, 0, 5000);
	}
    else
        return 1029;//could not open device
    return 0;
}
