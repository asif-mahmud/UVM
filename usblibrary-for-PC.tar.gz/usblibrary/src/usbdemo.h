#ifndef __USBDEMO_H_INCLUDED__
#define __USBDEMO_H_INCLUDED__

#include <usb.h>       /* this is libusb */
#include "opendevice.h" /* common code moved to separate module */

#include "../firmware/requests.h"   /* custom request numbers */
#include "../firmware/usbconfig.h"  /* device's VID/PID and names */

#include <stdint.h>


#define int_16 uint16_t
#define int_8  uint8_t


/*Global variables*/
usb_dev_handle      *handle = NULL;
const unsigned char rawVid[2] = {USB_CFG_VENDOR_ID}, rawPid[2] = {USB_CFG_DEVICE_ID};
char                vendor[] = {USB_CFG_VENDOR_NAME, 0}, product[] = {USB_CFG_DEVICE_NAME, 0};
char                buffer[1];
char 				_test[4];
static int          cnt, vid, pid;

/******************/


/*init_usb opens the usb and fills the handle */
/*returns :*/
/*256 = success*/
/*257 = USBOPEN_ERR_ACCESS*/
/*258 = USBOPEN_ERR_IO*/
/*259 = USBOPEN_ERR_NOTFOUND*/

int init_usb();

/**********************/

/*test function*/
/*takes a uint16_t value and sends it to usbdemo and reads the return*/
/*then compares it to given value if success returns 0 else 260*/

int test(unsigned val);

/*****************************/


/*this is the vital function*/
/*it reads the adc value from atmega*/


int read_adc();
/*****************************/



int set_load_cfg(unsigned char willMonitorLoad/*=0 doesnt monitor & =1 monitors load*/,
					unsigned char startValue/*must be adc value(0-255)*/,
					unsigned char stopValue/*must be adc value(0-255)*/);

#endif