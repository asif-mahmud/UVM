#include "jkmath.h"

string JKMath :: buildStr(char str[])
{
    string tmp = str;
    return tmp;
}

double JKMath :: str2num(string numberStr)
{
    return atof(numberStr.c_str());
}

double JKMath :: extractNum(string mainStr,int numberLength)
{
    string tmp;
    for(int i =0;i<numberLength;i++)
        tmp+=mainStr[i];

    return str2num(tmp);
}

string JKMath :: extractSubFunc(string mainFunc,int start, int end)
{
    string result;
    for(int i =start;i<=end;i++)
        result+=mainFunc[i];
    return result;
}

double JKMath :: evaluateSubFunc(double initialValue,string nextFunc)
{
    string tmp;

    ostringstream stream;
    stream<<initialValue;
    tmp = stream.str();

    nextFunc.insert(0,tmp);
    //cout<<"sub Func : "<<nextFunc<<"\n";
    return  evaluateFunc(nextFunc);
}


double JKMath :: evaluateFunc(string funcStr)
{
    double result = 0.0;
    int length = funcStr.length();
    //first try to extract a number with the first operator
    int i =0;
    char newOperator=NULL;
    do
    {
        if(funcStr[i]=='(')
        {
           int c = i+1;
           int startingBraceCount =0;
           int closingBraceCount = 0;
           for(;c<(length);c++)
           {
               if(funcStr[c]=='(')startingBraceCount++;
               else if(funcStr[c]==')')closingBraceCount++;
               if(closingBraceCount>startingBraceCount)break;
           }
           if(c!=(length-1))
           {
               double tmp = evaluateFunc(extractSubFunc(funcStr,i+1,c-1));
               return evaluateSubFunc(tmp,extractSubFunc(funcStr,c+1,length-1));
           }
           else
           {
               return evaluateFunc(extractSubFunc(funcStr,i+1,length-1));
           }
        }
        else if((funcStr[i]>='0'&&funcStr[i]<='9')||(funcStr[i]=='.'))
            i++;
        else
        {
            newOperator = funcStr[i];
            //cout<<i;
            break;
        }
    }
    while(!newOperator);//when it gets broken i will hold the operator position
                        //actually its holding the number length

    //now get the first number
    result = extractNum(funcStr,i);

    //now opertae on it
    switch(newOperator)
    {

    case '/':
        result/=evaluateFunc(extractSubFunc(funcStr,i+1,length-1));
        //cout<<result<<"/\n";
        break;
    case '*':
        result*=evaluateFunc(extractSubFunc(funcStr,i+1,length-1));
        //cout<<result<<"*\n";
        break;
    case '+':
        result+=evaluateFunc(extractSubFunc(funcStr,i+1,length-1));
        //cout<<result<<"+\n";
        break;
    case '-':
        result-=evaluateFunc(extractSubFunc(funcStr,i+1,length-1));
        //cout<<result<<"-\n";
        break;
    case '^':
        result = pow(result,evaluateFunc(extractSubFunc(funcStr,i+1,length-1)));
        break;
    default:
        break;
    }

    return result;
}

double JKMath :: evaluateFunc_2(string funcStr,char var,double varValue)
{
    //double result = 0.0;
    int length = funcStr.length();
    //change the var character with var value
    string tmpVar;
    //cout<<"fonud : "<<funcStr<<"\n";
    ostringstream stream;
    stream<<varValue;
    tmpVar = stream.str();
    for(int i = 0;i<length;i++)
    {
        if(funcStr[i]==var && funcStr[i]!='^')
        {
            funcStr.erase(i,1);
            //cout<<funcStr<<"after erase\n";
            funcStr.insert(i,tmpVar);
        }
    }
    //cout<<funcStr<<"\n";
    return evaluateFunc(funcStr);
}
