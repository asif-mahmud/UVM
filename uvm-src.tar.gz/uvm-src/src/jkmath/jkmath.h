#ifndef JKMATH_H
#define JKMATH_H

#include <iostream>
#include <sstream>
#include <stdlib.h>
#include <string>
#include <math.h>

using namespace std;

class JKMath
{
public :
    static string buildStr(char str[]);
    static double str2num(string numberStr);
    static double extractNum(string mainStr,int numberLength);
    static double evaluateFunc(string funcStr);
    static double evaluateFunc_2(string funcStr,char var,double varValue);
    static string extractSubFunc(string mainFunc,int start, int end);
    static double evaluateSubFunc(double initialValue,string nextFunc);

};

#endif // JKMATH_H
