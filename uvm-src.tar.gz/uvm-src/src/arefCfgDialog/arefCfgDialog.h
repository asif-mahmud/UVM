#ifndef AREFCFGDIALOG_H
#define AREFCFGDIALOG_H

#include <QtGui>
#include <QDialog>

class ArefCfgDialog : public QDialog
{
    Q_OBJECT
public :
    ArefCfgDialog(float * aref, QWidget * parent =0);
    void showDialog(float * aref);

private:
    QLabel * l1;
    QLineEdit * edit;
    QPushButton * change;
    QPushButton * cancel;

    float *aref;

private slots:
    void changeAref();
};

#endif // AREFCFGDIALOG_H
