#include "arefCfgDialog.h"
#include <QFile>

ArefCfgDialog::ArefCfgDialog(float *aref, QWidget *parent):QDialog(parent)
{
    if(!QFile::exists("cfg/aref.cfg"))
    {
        QMessageBox::warning(this,"Error","Could not find the configuration file.\nPlease reinstall the program");
        this->close();
    }
    else
    {
        QString arefStr = "";
        QFile file("cfg/aref.cfg");
        if(!file.open(QFile::ReadWrite))
        {
            QMessageBox::warning(this,"Error","Could not find the configuration file.\nPlease reinstall the program");
        }
        else
        {
            arefStr = file.readAll();
            *aref = arefStr.toFloat();
            file.close();
        }

        l1 = new QLabel ("reference of the device :");
        edit = new QLineEdit(arefStr);
        change = new QPushButton("Change");
        cancel = new QPushButton("Cancel");

        QHBoxLayout * up = new QHBoxLayout() ;
        up->addWidget(l1);
        up->addWidget(edit);

        QHBoxLayout * down = new QHBoxLayout() ;
        down->addWidget(change);
        down->addWidget(cancel);

        QVBoxLayout * ml = new QVBoxLayout() ;
        ml->addLayout(up);
        ml->addLayout(down);

        setLayout(ml);

        connect(cancel,
                SIGNAL(clicked()),
                this,
                SLOT(close()));
        connect(change,
                SIGNAL(clicked()),
                this,
                SLOT(changeAref()));
    }
}


void ArefCfgDialog::showDialog(float *aref)
{
    this->aref = aref;
    this->show();
}

void ArefCfgDialog :: changeAref()
{
    QString arefStr = edit->text();
    *aref = arefStr.toFloat();
    QFile file("cfg/aref.cfg");
    if(!file.open(QFile::ReadWrite))
    {
        QMessageBox::warning(this,"Error","Could not find the configuration file.\nPlease reinstall the program");
    }
    else
    {
        file.resize(0);
        file.write(arefStr.toAscii());
        file.close();
        this->close();
    }
}
