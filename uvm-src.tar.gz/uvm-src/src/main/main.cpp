#include <QApplication>
#include "../mainwin/mainwin.h"

int main(int argc ,char * argv[])
{
    QApplication app(argc,argv);

    if (!QGLFormat::hasOpenGL()) {
           // << "This system has no OpenGL support" << std::endl;
            return 1;
        }



    MainWin mainWin;
    mainWin.centerIt();
    mainWin.show();

    //mainWin.resize(mainWin.width()+10,mainWin.height()+10);
    //mainWin.resize(mainWin.width()-10,mainWin.height()-10);
    return app.exec();
}

