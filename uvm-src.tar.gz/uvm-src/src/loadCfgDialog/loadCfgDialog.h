#ifndef LOADCFGDIALOG_H
#define LOADCFGDIALOG_H

#include<QtGui>

class LoadCfgDialog:public QDialog
{
    Q_OBJECT

public :
    LoadCfgDialog(QDialog *parent=0);
    void Show(bool *isInControllingMode , unsigned char * startADC, unsigned char *stopADC,float *aref );


    bool *isInControllingMode ;
    unsigned char * startADC;
    unsigned char *stopADC;
    float * aref;


private:
    QCheckBox * willControlLoad;
    QLabel *l1 ,*l2;
    QLineEdit *startVolt,*stopVolt;
    QPushButton *ok, *cancel;

private slots:
    void saveCfg();
};

#endif // LOADCFGDIALOG_H
