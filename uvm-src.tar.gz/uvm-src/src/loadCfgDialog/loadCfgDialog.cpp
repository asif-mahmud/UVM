#include "loadCfgDialog.h"

LoadCfgDialog::LoadCfgDialog(QDialog *parent):QDialog(parent)
{

    willControlLoad = new QCheckBox("Run in Load Controlling Mode");

    l1 = new QLabel("Start Voltage \n(must be between 0- aref) : ");
    l2 = new QLabel("Stop Voltage \n(must be between 0- aref) : ");

    startVolt = new QLineEdit();
    stopVolt = new QLineEdit();


    ok = new QPushButton("Ok");
    cancel = new QPushButton("Cancel");


    QVBoxLayout * ll = new QVBoxLayout();
    ll->addWidget(l1);
    ll->addWidget(l2);
    ll->addWidget(ok);
    QVBoxLayout *lr = new QVBoxLayout();
    lr->addWidget(startVolt);
    lr->addWidget(stopVolt);
    lr->addWidget(cancel);
    QHBoxLayout * mid = new QHBoxLayout();
    mid->addLayout(ll);
    mid->addLayout(lr);

    QVBoxLayout *ml = new QVBoxLayout();
    ml->addWidget(willControlLoad);
    ml->addLayout(mid);

    setLayout(ml);


    connect(cancel,
            SIGNAL(clicked()),
            this,
            SLOT(close()));
    connect(ok,
            SIGNAL(clicked()),
            this,
            SLOT(saveCfg()));
}


void LoadCfgDialog::Show(bool *isInControllingMode , unsigned char * startADC, unsigned char *stopADC,float *aref )
{

    this->isInControllingMode = isInControllingMode;
    this->startADC = startADC;
    this->stopADC = stopADC;
    this->aref = aref;
    this->willControlLoad->setChecked(*isInControllingMode);
    startVolt->setText(QString::number((((float)(*startADC)*(*aref))/256.0)));
    stopVolt->setText(QString::number((((float)(*stopADC)*(*aref))/256.0)));
    show();
}


void LoadCfgDialog::saveCfg()
{
    *isInControllingMode = willControlLoad->isChecked();
    if(startVolt->text().toFloat()<*aref)
        *startADC = (unsigned char)(((startVolt->text().toFloat())*256)/(*aref));
    if(stopVolt->text().toFloat()<*aref)
        *stopADC = (unsigned char)(((stopVolt->text().toFloat())*256)/(*aref));

    //QMessageBox::warning(this,"",QString::number((((float)(*startADC)*(*aref))/256.0)));

    close();
}
