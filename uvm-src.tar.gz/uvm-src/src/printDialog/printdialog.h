#ifndef PRINTDIALOG_H
#define PRINTDIALOG_H

#include <QtGui>
#include <QDialog>

class PrintGraph : public QDialog
{
    Q_OBJECT
public :
    PrintGraph(QWidget * parent =0);
    void showDialog(QPixmap mainPix);

private:
    QLabel      * l1;
    QLabel      * l2;
    QLabel      * l3;
    QLabel      * l4;
    QLabel      * l5;
    QLabel      * l6;

    QLineEdit   * sampleTitle;
    QLineEdit   * sampleNo;
    QLineEdit   * objective ;
    QLineEdit   * preparedBy;
    QLineEdit   * date;
    QLineEdit   * time ;

    QPushButton * ok ;
    QPushButton * cancel;

    QPixmap mainPix;
    QPixmap titlePix;
    QPixmap pixToPrint;



private slots:
    void print();
};

#endif // PRINTDIALOG_H
