#include "printdialog.h"

PrintGraph::PrintGraph(QWidget *parent):QDialog(parent)
{
    l1 = new QLabel("Sample Title :");
    l2 = new QLabel("Sample no    :");
    l3 = new QLabel("Objective    :");
    l4 = new QLabel("Prepared by  :");
    l5 = new QLabel("Date         :");
    l6 = new QLabel("Time         :");
    ok = new QPushButton("Ok");


    QVBoxLayout * ly1 = new QVBoxLayout();
    ly1->addWidget(l1);
    ly1->addWidget(l2);
    ly1->addWidget(l3);
    ly1->addWidget(l4);
    ly1->addWidget(l5);
    ly1->addWidget(l6);
    ly1->addWidget(ok);

    sampleTitle = new QLineEdit("untitled");
    sampleNo = new QLineEdit("1");
    objective = new QLineEdit("as the title says");
    preparedBy = new QLineEdit("none");
    date = new QLineEdit(QDate::currentDate().toString());
    time = new QLineEdit(QTime::currentTime().toString());
    cancel = new QPushButton("Cancel");

    QVBoxLayout * ly2 = new QVBoxLayout();
    ly2->addWidget(sampleTitle);
    ly2->addWidget(sampleNo);
    ly2->addWidget(objective);
    ly2->addWidget(preparedBy);
    ly2->addWidget(date);
    ly2->addWidget(time);
    ly2->addWidget(cancel);

    QHBoxLayout * lup = new QHBoxLayout();
    lup->addLayout(ly1);
    lup->addLayout(ly2);

    setLayout(lup);
    setFixedSize(250,200);
    setWindowTitle("Print the Graph");

    connect(cancel,
            SIGNAL(clicked()),
            this,
            SLOT(close()));

    connect(ok,
            SIGNAL(clicked()),
            this,
            SLOT(print()));
}

void PrintGraph :: showDialog(QPixmap mainPix)
{
    this->mainPix = mainPix;

    date->setText(QDate::currentDate().toString());
    time->setText(QTime::currentTime().toString());
    this->show();
}


void PrintGraph :: print()
{
    titlePix = QPixmap(640,100);
    titlePix.fill();
    QPainter painter(&titlePix);
    painter.begin(&titlePix);
    painter.drawRect(0,0,639,99);
    QFont font ;
    font.setPixelSize(12);
    painter.setFont(font);
    painter.drawText(15,20,"Sample Title      ");
    painter.drawText(250,20,": "+sampleTitle->text());
    painter.drawText(15,33,"Sample no         ");
    painter.drawText(250,33,": "+sampleNo->text());
    painter.drawText(15,46,"Objective         ");
    painter.drawText(250,46,": "+objective->text());
    painter.drawText(15,59,"Prepared by     ");
    painter.drawText(250,59,": "+preparedBy->text());
    painter.drawText(15,72,"Date                ");
    painter.drawText(250,72,": "+date->text());
    painter.drawText(15,85,"Time                ");
    painter.drawText(250,85,": "+time->text());
    painter.end();

    pixToPrint = QPixmap(640,600);
    pixToPrint.fill();
    painter.begin(&pixToPrint);
    painter.drawPixmap(0,0,titlePix);
    painter.drawPixmap(0,110,mainPix.scaled(640,480));
    painter.end();

    QPrinter *printer = new QPrinter;
    //printer->setOrientation(QPrinter::Landscape);


            //QPrintPreviewDialog *printDialog = new QPrintPreviewDialog(printer, this);
            QPrintDialog *printDialog = new QPrintDialog(printer, 0);
            if (printDialog->exec() == QDialog::Accepted) {
                        QPainter qpainter;
                        qpainter.begin(printer);


                        //myWidget->render(&painter);
                        qpainter.drawPixmap(100,100,pixToPrint);
                        qpainter.end();
                        close();
            }

}

