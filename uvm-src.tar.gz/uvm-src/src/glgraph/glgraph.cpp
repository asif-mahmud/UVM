#include "glgraph.h"


GLGraph :: GLGraph(float *aref, QWidget *parent):QGLWidget(parent)
{
    x_scale_str = "X Scale : ";
    y_scale_str = "Y Scale : ";
    currentIndex = -1;
    this->aref = aref;
    adcValues = NULL;

    setMinimumSize(640,480);
    setFormat(QGLFormat(QGL::DoubleBuffer));

}



void GLGraph ::mousePressEvent(QMouseEvent *event)
{
    if(currentIndex!=-1)
    {
        float x_pos = (event->pos().x()-x_zero)*(timeInterval/x_interval)/1000;
        float y_pos = (graphHeight - event->pos().y())*(y_max/(4.0*y_span));
        QStringList list = y_unit.split("/");

        QToolTip::showText(QCursor::pos(),QString::number(x_pos)+"sec\n"+QString::number(y_pos)+list.value(0)+"\n");
        //QToolTip::showText(QCursor::pos(),QString::number()+"\n"+QString::number()+"\n");
    }
}

