#ifndef GLGRAPH_H
#define GLGRAPH_H

#include <QtGui>
#include <QGLWidget>

class GLGraph : public QGLWidget
{
    Q_OBJECT

public :
    GLGraph(float * aref, QWidget * parent =0);

    //OpenGL functions
public :
        //these are initial functions to initialize or paint the GL widget
    //they are located in ../opengl/init.cpp file
    int graphWidth,graphHeight;
    int width ,height;
    int x_zero, y_zero_const;
    int y_zero;
    int x_axis,y_axis;
    float x_span ,y_span;
    QString x_scale_str,y_scale_str;

    float x_interval;
    float * y_values;
    float * voltage_values;
    float y_constant;
    int currentIndex;

    int samplesToTake;
    int sampleTimeInterval;
    int timeInterval;
    float y_coefficient;
    float y_max;
    QString y_unit;
    int  * adcValues;

    float * aref;

    bool isGridDrawn ;

    void initializeGL();
    void resizeGL(int width , int height);
    void paintGL();


protected:
    void glDrawLine(QPoint p1, QPoint p2 ,float lineWidth = 1.0, QColor c = Qt::black);
    void glDrawDashLine(QPoint p1, QPoint p2 ,float lineWidth = 1.0, QColor c = Qt::black);
    void glDrawRect(int topLeft , int topRight , int width , int height , float lineWidth=1.0, QColor c = Qt::black);


public:
    void drawGrid();
    void drawCurve();

    void mousePressEvent(QMouseEvent * event);

};


#endif // GLGRAPH_H
