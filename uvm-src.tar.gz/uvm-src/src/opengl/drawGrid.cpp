#include "../glgraph/glgraph.h"

void GLGraph::drawGrid()
{
    //glDrawDashLine(QPoint(10,50),QPoint(350,50),3.0);
    glDrawRect(0,0,width,height,2.5);

    QColor dashLineColor(182,186,9);

    glDrawLine(QPoint(0,x_axis),QPoint(width,x_axis),1.5,dashLineColor);
    glDrawLine(QPoint(y_axis,0),QPoint(y_axis,height),1.5,dashLineColor);

    for(int i =1 ; i<4 ; i++)
    {
        glDrawDashLine(QPoint(y_axis,x_axis-i*y_span),
                       QPoint(width,x_axis-i*y_span),1.0,dashLineColor);
        glDrawDashLine(QPoint(x_zero+i*x_span,0),
                       QPoint(x_zero+i*x_span,x_axis),1.0,dashLineColor);
    }

    qglColor(Qt::black);

    QFont fontPrev(this->font());
    QFont font;
    font.setBold(true);
    font.setFamily("Courier");
    font.setPixelSize(14);
    setFont(font);

    //renderText(x_zero-20,y_zero+15,"(0,0)");
    renderText(10,15,x_scale_str);
    renderText(10,30,y_scale_str);

    for(int i=0;i<4;i++)
    {
        renderText(5,y_zero-i*(y_max/4.0)*y_constant,QString::number(i*(y_max/4.0)));
        renderText((x_zero+(i*(graphWidth/4.0))),y_zero+20,QString::number((((float)(samplesToTake/4.0)*timeInterval)/1000)*i));
    }


    setFont(fontPrev);

    glFlush();
}
