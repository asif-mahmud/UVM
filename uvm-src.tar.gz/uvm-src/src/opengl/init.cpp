#include "../glgraph/glgraph.h"


void GLGraph :: initializeGL()
{
    qglClearColor(Qt::white);
    glShadeModel(GL_FLAT);
    glDisable(GL_DEPTH_TEST);
    glEnable(GL_CULL_FACE);
}

void GLGraph :: resizeGL(int width, int height)
{

    this->width = width;
    this->height = height;
    x_zero = 40;
    y_zero_const = 40;
    y_zero = this->height-y_zero_const;
    x_axis = y_zero;
    y_axis = x_zero;
    graphWidth = this->width-x_zero;
    graphHeight = y_zero;
    x_span = (float)graphWidth/4.0;
    y_span = (float)graphHeight/4.0;
    y_constant = ((y_span*4.0)/y_max);


     glMatrixMode (GL_PROJECTION);
     glLoadIdentity ();
     glViewport(0, 0, width, height);
     glOrtho (0, width, height, 0, 0, 1);
     glMatrixMode (GL_MODELVIEW);
}

void GLGraph :: paintGL()
{
   glClear(GL_COLOR_BUFFER_BIT);
   drawGrid();
   drawCurve();
}




