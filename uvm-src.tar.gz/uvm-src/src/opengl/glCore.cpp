#include "../glgraph/glgraph.h"

void GLGraph :: glDrawLine(QPoint p1, QPoint p2,float lineWidth, QColor c)
{
    qglColor(c);
    glLineWidth(lineWidth);
    glDisable(GL_LINE_STIPPLE);

    glBegin(GL_LINES);
    glVertex2i(p1.x(),p1.y());
    glVertex2i(p2.x(),p2.y());
    glEnd();

}

void GLGraph ::glDrawDashLine(QPoint p1, QPoint p2, float lineWidth, QColor c)
{
    qglColor(c);
    glLineWidth(lineWidth);
    glLineStipple(1,0xaaaaaa);
    glEnable(GL_LINE_STIPPLE);


    glBegin(GL_LINES);
    glVertex2i(p1.x(),p1.y());
    glVertex2i(p2.x(),p2.y());
    glEnd();
}


void GLGraph :: glDrawRect(int topLeft, int topRight, int width, int height,float lineWidth, QColor c)
{
    glDrawLine(QPoint(topLeft,topRight),QPoint(topLeft+width,topRight),lineWidth,c);
    glDrawLine(QPoint(topLeft+width,topRight),QPoint(topLeft+width,topRight+height),lineWidth,c);
    glDrawLine(QPoint(topLeft+width,topRight+height),QPoint(topLeft,topRight+height),lineWidth,c);
    glDrawLine(QPoint(topLeft,topRight+height),QPoint(topLeft,topRight),lineWidth,c);
}


