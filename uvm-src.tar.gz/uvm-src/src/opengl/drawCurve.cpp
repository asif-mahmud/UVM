#include "../glgraph/glgraph.h"


void GLGraph :: drawCurve()
{
    if(currentIndex>0)
    {
        for(int i = 0 ; i<currentIndex-1;i++)
        {
            glDrawLine(QPoint((x_zero+(i*x_interval)),y_zero-y_values[i]*y_constant),
                       QPoint(x_zero+(i+1)*x_interval,y_zero-y_values[i+1]*y_constant),
                       2.5,
                       Qt::blue);
        }
    }
}
