#include "mainwin.h"
#include "../jkmath/jkmath.h"

void MainWin::doAll()
{
    if(isFreeRunning)
    {
        if(counter<200)
        {
            graph->adcValues[counter] = usbDev.read_adc();
            if(graph->adcValues[counter]>254)
            {
                if(graph->adcValues[counter]<=255)
                    QMessageBox::warning(this,"Warning","Input exceeding Aref value");
                else if(graph->adcValues[counter]>255)
                    QMessageBox::warning(this,"Warning","Device Disconnected ... \nPlease reconnect the device\n");
                timer->stop();
            }
            else
            {
                graph->voltage_values[counter] = ((graph->adcValues[counter]*aref)/256);
                graph->y_values[counter] = (float)JKMath::evaluateFunc_2(y_func_str,'x',graph->voltage_values[counter]);
                graph->currentIndex = counter;
                graph->updateGL();
                counter++;
            }

        }
        else if(counter == 200)
        {
            counter =0;
            graph->currentIndex =0;
            for(int i =0;i<200;i++)
            {
                graph->adcValues[i]=0;
                graph->y_values[i]=0;
                graph->voltage_values[i]=0;                
            }
        }
    }
    else if(isTakingSamples)
    {
        if(counter<graph->samplesToTake)
        {
            graph->adcValues[counter] = usbDev.read_adc();
            if(graph->adcValues[counter]>254)
            {
                if(graph->adcValues[counter]<=255)
                    QMessageBox::warning(this,"Warning","Input exceeding Aref value");
                else if(graph->adcValues[counter]>255)
                    QMessageBox::warning(this,"Warning","Device Disconnected ... \nPlease reconnect the device\n");
                timer->stop();
            }
            else
            {
                graph->voltage_values[counter] = ((graph->adcValues[counter]*aref)/256);
                graph->y_values[counter] = (float)JKMath::evaluateFunc_2(y_func_str,'x',graph->voltage_values[counter]);
                graph->currentIndex = counter;
                graph->updateGL();
                counter++;
            }

        }
        else if(counter==graph->samplesToTake)
        {
            if(timer->isActive() && isTakingSamples)
                timer->stop();
        }
    }
}
