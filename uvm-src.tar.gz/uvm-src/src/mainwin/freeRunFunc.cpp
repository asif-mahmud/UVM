#include "mainwin.h"


void MainWin::startFreeRubFunc()
{
    graph->adcValues = new int[200];
    graph->y_values = new float[200];
    graph->voltage_values = new float[200];

    for(int i =0;i<100;i++)
    {
        graph->adcValues[i]=0;
        graph->y_values[i]=0;
        graph->voltage_values[i]=0;
    }

    counter = 0;
    isFreeRunning = true;
    isTakingSamples = false;

    graph->timeInterval = 100;
    graph->samplesToTake = 200;
    float tmp = ((float)(200.0/4.0)*graph->timeInterval)/1000.0;
    graph->x_interval = graph->x_span/(200.0/4.0);
    graph->x_scale_str = "X Scale : "+QString::number(tmp)+" sec/div";
    graph->y_scale_str = "Y Scale : "+QString::number((graph->y_max/4.0))+" "+QString::fromStdString(y_unit_string);

    graph->y_constant = ((graph->y_span*4.0)/graph->y_max);
    graph->y_unit = QString::fromStdString(y_unit_string);


    if(isInControllingMode)
        usbDev.set_load_cfg(1,startADC,stopADC);
    else
        usbDev.set_load_cfg(1,0,0);

    timer->start(graph->timeInterval);
}

void MainWin::stopFreeRunFunc()
{
    if(timer->isActive() && isFreeRunning)
        timer->stop();    
}
