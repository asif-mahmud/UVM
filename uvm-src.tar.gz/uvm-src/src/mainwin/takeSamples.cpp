#include "mainwin.h"

void MainWin::startTakingSamples()
{
    graph->adcValues = new int[graph->samplesToTake];
    graph->y_values = new float[graph->samplesToTake];
    graph->voltage_values = new float[graph->samplesToTake];

    for(int i =0;i<graph->samplesToTake;i++)
    {
        graph->adcValues[i]=0;
        graph->y_values[i]=0;
        graph->voltage_values[i]=0;
    }

    counter = 0;
    isFreeRunning = false;
    isTakingSamples = true;

    graph->timeInterval = graph->sampleTimeInterval;

    float tmp = ((float)(graph->samplesToTake/4.0)*graph->sampleTimeInterval)/1000;
    graph->x_interval = graph->x_span/((float)graph->samplesToTake/4.0);
    graph->x_scale_str = "X Scale : "+QString::number(tmp)+" sec/div";
    graph->y_scale_str = "Y Scale : "+QString::number((graph->y_max/4.0))+" "+QString::fromStdString(y_unit_string);

    graph->y_constant = ((graph->y_span*4.0)/graph->y_max);
    graph->y_unit = QString::fromStdString(y_unit_string);
    timer->start(graph->timeInterval);
}
