#include <qfile.h>
#include <qtextstream.h>
#include "mainwin.h"

MainWin ::MainWin(QWidget *parent):QMainWindow(parent)
{

    isFreeRunning = false;
    isTakingSamples = false;
    isInControllingMode =false;
    startADC = 0;
    stopADC =0;

    timer = new QTimer();

    tools = new QToolBar("Tools");
    tools->setToolButtonStyle(Qt::ToolButtonTextBesideIcon);
    startSample = tools->addAction(QIcon("icons/start.png"),"Take Samples");
    startFreeRun = tools->addAction(QIcon("icons/start_free_run.png"),"Start Free Run");
    stopFreeRun = tools->addAction(QIcon("icons/stop_free_run.png"),"Stop Free Run");
    print = tools->addAction((QIcon("icons/print.png")),"Print");
    saveData = tools->addAction(QIcon("icons/save_data.png"),"Save Last Data");
    saveImage = tools->addAction(QIcon("icons/save_image.png"),"Save Image");
    addToolBar(tools);

    QMenu * fileMenu = menuBar()->addMenu("&File");
    printMenu = fileMenu->addAction("&Print");
    saveImageMenu = fileMenu->addAction("Save as Bitmap &Image");
    saveDataMenu = fileMenu->addAction("Save data");
    QMenu  * actions = menuBar()->addMenu("Actions");
    startSampleMenu = actions->addAction("Take Samples");
    startFreeRunMenu = actions->addAction("Start Free Run");
    stopFreeRunMenu = actions->addAction("Stop Free Run");
    QMenu  * config = menuBar()->addMenu("&Configure");
    arefCfgMenu = config->addAction("Configure aref");
    yCfgMenu = config->addAction("Configure y scale");
    cfgSampleNoMenu = config->addAction("Samples to take");
    loadCfgMenu = config->addAction("Configure Load Controlling");
    about = menuBar()->addAction("About");


    arefCfgDialog = new ArefCfgDialog(&this->aref);
    yCfgDialog = new YCfgDialog();
    cfgSampleNo = new CfgSampleNo();
    loadCfgDialog = new LoadCfgDialog();

    //int r = usbDev.set_load_cfg(1,10,200);
    //if(r>1024)
       //QMessageBox::warning(this,"Error","Colud not send Configuration data \nCode : "+QString::number(r));


    graph = new GLGraph(&this->aref);
    setCentralWidget(graph);

    QFile file("cfg/y_func.cfg");
    if(file.exists())
    {
        if(!file.open(QIODevice::ReadWrite))
        {
            QMessageBox::warning(this,"Error","Could not open y_func.cfg\nPLease start the program with admin priviledge.");
        }
        else
        {
            QTextStream in(&file);
            QString line = in.readLine();
            int cnt =0;
                while (!line.isNull()) {
                    switch(cnt)
                    {
                    case 0:
                        y_unit_string = line.toStdString();
                        cnt++;
                        break;
                    case 1:
                        y_func_str = line.toStdString();
                        cnt++;
                        break;
                    case 2:
                        graph->y_max = line.toFloat();
                        cnt++;
                        break;
                    default:
                        break;
                    }
                    line = in.readLine();
                }
                file.close();
        }
    }
    else
    {
        QMessageBox::warning(this,"Error","Could not find y_func.cfg\nCreating a default one.");
        file.open(QIODevice::ReadWrite);
        QTextStream strm(&file);
        QString str = "volt/div\n";
        y_unit_string ="volt/div";
        str+="x\n";
        y_func_str = "x";
        str+=(QString::number(aref)+"\n");
        graph->y_max = aref;
        file.write((const char*)str.toAscii().data());
        file.close();
    }
    QFile file2("cfg/smpl.cfg");
    if(file2.exists())
    {
        if(!file2.open(QIODevice::ReadWrite))
        {
            QMessageBox::warning(this,"Error","Could not open smpl.cfg\nPLease start the program with admin priviledge.");
        }
        else
        {
            QTextStream in(&file2);
            QString line = in.readLine();
            graph->samplesToTake = line.toInt();
            line = in.readLine();
            graph->sampleTimeInterval = line.toInt();
            file2.close();
        }
    }
    else
    {
        QMessageBox::warning(this,"Error","Could not find smpl.cfg\nCreating a default one.");
        file2.open(QIODevice::ReadWrite);
        QTextStream strm(&file2);
        QString str = "250\n";
        graph->samplesToTake = 250;
        str+="100\n";
        graph->sampleTimeInterval = 100;

        file2.write((const char*)str.toAscii().data());
        file2.close();
    }

    connect(saveImage,
            SIGNAL(triggered()),
            this,
            SLOT(saveImageFunc()));
    connect(saveImageMenu,
            SIGNAL(triggered()),
            this,
            SLOT(saveImageFunc()));

    connect(print,
            SIGNAL(triggered()),
            this,
            SLOT(printGraphFunc()));
    connect(printMenu,
            SIGNAL(triggered()),
            this,
            SLOT(printGraphFunc()));
    connect(saveData,
            SIGNAL(triggered()),
            this,
            SLOT(saveDatas()));
    connect(saveDataMenu,
            SIGNAL(triggered()),
            this,
            SLOT(saveDatas()));

    connect(arefCfgMenu,
            SIGNAL(triggered()),
            this,
            SLOT(configureAref()));
    connect(yCfgMenu,
            SIGNAL(triggered()),
            this,
            SLOT(configureY()));
    connect(cfgSampleNoMenu,
            SIGNAL(triggered()),
            this,
            SLOT(configureSampleNo()));
    connect(loadCfgMenu,
            SIGNAL(triggered()),
            this,
            SLOT(configureLoad()));

    connect(startSample,
            SIGNAL(triggered()),
            this,
            SLOT(startTakingSamples()));
    connect(startSampleMenu,
            SIGNAL(triggered()),
            this,
            SLOT(startTakingSamples()));

    connect(startFreeRun,
            SIGNAL(triggered()),
            this,
            SLOT(startFreeRubFunc()));
    connect(startFreeRunMenu,
            SIGNAL(triggered()),
            this,
            SLOT(startFreeRubFunc()));
    connect(stopFreeRun,
            SIGNAL(triggered()),
            this,
            SLOT(stopFreeRunFunc()));
    connect(stopFreeRunMenu,
            SIGNAL(triggered()),
            this,
            SLOT(stopFreeRunFunc()));
    connect(timer,
            SIGNAL(timeout()),
            this,
            SLOT(doAll()));


    connect(about,
            SIGNAL(triggered()),
            this,
            SLOT(aboutDialog()));

}

void MainWin ::aboutDialog()
{
    QMessageBox::about(this,
                       "About UVM v3.0",
                       "USB Voltmeter\n================\n\n\nThis Program is developed by :\n\nAsif Mahmud Shimon\nRUET\nEEE 09");
}

void MainWin :: resizeEvent(QResizeEvent *event)
{
    graph->updateGL();

    if(isFreeRunning)
    {graph->x_interval = graph->x_span/(200.0/4.0);}
    else if(isTakingSamples)
    {graph->x_interval = graph->x_span/((float)graph->samplesToTake/4.0);}

    graph->updateGL();
}



void MainWin :: centerIt()
{
    QDesktopWidget * d= QApplication::desktop();
    int screenWidth = d->width();
    int screenHeight = d->height();

    this->move((screenWidth-width())/2 , (screenHeight-height())/2);
}


void MainWin ::saveImageFunc()
{
    QString fileName = QFileDialog::getSaveFileName(this,
                       "Save the gtaph as Bitmap image",
                       "",
                       tr("As Image file (*.bmp)"));


    QPixmap pix = QPixmap::grabWidget(graph);
    if(!fileName.contains(".bmp"))fileName+=".bmp";
    if(fileName!=NULL)
    {
        if(!pix.save(fileName,"BMP"))
          QMessageBox::warning(this,"Error","Could not save the image");
    }

}


void MainWin :: saveDatas()
{
    if(graph->adcValues !=NULL)
    {
        QString fileName = QFileDialog::getSaveFileName(this,
                                                    "Save the last data as txt",
                                                    "",
                                                    tr("As Text file (*.txt)"));


        if(!fileName.contains(".txt"))fileName+=".txt";
        if(fileName!=NULL)
       {
        QFile * file = new QFile(fileName);
        if(file->open(QIODevice::WriteOnly| QIODevice::Text))
        {

            QString tmp ;
            QString date = QDate::currentDate().toString();
            QString time = QTime::currentTime().toString();
            tmp+="Data Saved by uvm programm\n";
            tmp+=("Date : "+date+"\nTime : "+time+"\n");
            tmp+="===========================\n";
            tmp+="Local parameters :\n==================\n";
            tmp+=("Total samples    : "+QString::number(graph->samplesToTake)+"\n");
            tmp+=("Function(x=volt) : "+QString::fromStdString(y_func_str)+"\n");
            tmp+=("Interval         : "+QString::number(graph->timeInterval)+"\n");
            tmp+=("Maximum Value    : "+QString::number(graph->y_max)+"\nSample No    Time(ms)      Voltage values    Function Values\n==============================================================\n");
            for(int i=0;i<graph->samplesToTake;i++)
                tmp+=(QString::number(i+1)+".\t\t" + QString::number(graph->timeInterval *i)+ "\t\t" + QString::number(graph->voltage_values[i])+"\t\t"+QString::number(graph->y_values[i])+"\n");

            file->write((const char*)tmp.toAscii().data());

            file->close();
        }
        else
            QMessageBox::warning(this,"Error saving data","Error while saving datas\nTry to save it in another location please.");
    }

    }
    else
    {
        QMessageBox::warning(this,"Error","No datas found");
    }
}

void MainWin::printGraphFunc()
{
    printGraph.showDialog(QPixmap::grabWidget(graph));
}

void MainWin::configureAref()
{
    arefCfgDialog->showDialog(&this->aref);
}


void MainWin::configureY()
{
    yCfgDialog->ShowDialog(&this->y_unit_string,&this->y_func_str,&graph->y_max);
}


void MainWin::configureSampleNo()
{
    cfgSampleNo->ShowDialog(&graph->samplesToTake,&graph->sampleTimeInterval);
}

void MainWin::configureLoad()
{
    loadCfgDialog->Show(&(this->isInControllingMode),&(this->startADC),&(this->stopADC),&(this->aref));
}
