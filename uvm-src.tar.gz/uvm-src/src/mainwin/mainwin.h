#ifndef MAINWIN_H
    #define MAINWIN_H

#include <QtGui>
#include <QMainWindow>
#include "../glgraph/glgraph.h"
#include "../printDialog/printdialog.h"
#include "../usbdev/usbdev.h"
#include "../arefCfgDialog/arefCfgDialog.h"
#include "../yCfgDialog/ycfgdialog.h"
#include "../sampleNumberCfgDialog/cfgSampleNo.h"
#include "../loadCfgDialog/loadCfgDialog.h"

class MainWin : public QMainWindow
{
    Q_OBJECT

public :
    MainWin(QWidget  * parent =0);
    void resizeEvent(QResizeEvent * event);
    void centerIt();

private :
    GLGraph * graph;

    QToolBar    * tools;
    QAction     * startSample;
    QAction     * startFreeRun;
    QAction     * stopFreeRun;
    QAction     * print;
    QAction     * saveData ;
    QAction     * saveImage;


    QAction     * startSampleMenu;
    QAction     * startFreeRunMenu;
    QAction     * stopFreeRunMenu;
    QAction     * printMenu;
    QAction     * saveDataMenu ;
    QAction     * saveImageMenu;
    QAction     * arefCfgMenu;
    QAction     * yCfgMenu;
    QAction     * cfgSampleNoMenu;
    QAction     * loadCfgMenu;
    QAction     * about;

    PrintGraph printGraph;
    ArefCfgDialog * arefCfgDialog;
    YCfgDialog * yCfgDialog;
    CfgSampleNo * cfgSampleNo;
    LoadCfgDialog *loadCfgDialog;


    UsbDev usbDev;
    QTimer * timer;
    bool isFreeRunning;
    bool isTakingSamples;

    std::string y_func_str;
    std::string y_unit_string;


private slots:
    void saveImageFunc();
    void printGraphFunc();
    void configureAref();
    void configureLoad();
    void configureY();
    void configureSampleNo();

    void startFreeRubFunc();
    void stopFreeRunFunc();

    void startTakingSamples();

    void doAll();

    void aboutDialog();
    void saveDatas();

public:
    float aref;
    int counter;

    bool isInControllingMode;
    unsigned char startADC,stopADC;
};

#endif
