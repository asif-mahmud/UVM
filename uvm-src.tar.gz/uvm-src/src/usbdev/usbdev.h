#ifndef USBDEV_H
#define USBDEV_H

#include <QString>
#include <QLibrary>
#include <QtGui>

//#define     LIBWIN 1
//#define   LIBLINUX    1

class UsbDev
{
public :
    UsbDev();

private :
    QString libFile ;
    QLibrary    * library;
    typedef int (* prototype)();
    typedef int (* func)(unsigned char , unsigned char , unsigned char);

public :
    prototype   init_usb;
    prototype   read_adc;
    func   set_load_cfg;
private:
    QWidget     * tmp;
};

#endif // USBDEV_H
