#include "usbdev.h"

UsbDev :: UsbDev()
{


#ifdef LIBWIN
    libFile = "drv/usbdm.dll";

#endif
#ifdef LIBLINUX
    libFile = "drv/libusbdm.so";
#endif
    library = new QLibrary(libFile);



    tmp = new QWidget;


    if(!library->load())
        QMessageBox::warning(tmp,"Error","Error loading library");
    else
        library->unload();


    init_usb = (prototype)library->resolve("init_usb");


    if(!init_usb)
        QMessageBox::warning(tmp,"Error","Error loading Function");
    else
    {
        if(init_usb()>255)
            QMessageBox::warning(tmp,"Error","Device not Found .\nPlease check the connections");
        //else
            //QMessageBox::warning(tmp,"Welcome","Device loaded with code : \n"+QString::number(init_usb()));
    }

    read_adc = (prototype)library->resolve("read_adc");
    if(!read_adc)
        QMessageBox::warning(tmp,"Error","Error loading read Function");

    set_load_cfg = (func)library->resolve("set_load_cfg");
    if(!set_load_cfg)
        QMessageBox::warning(tmp,"Error","Error loading set_load_cfg Function");
}


