#ifndef YCFGDIALOG_H
#define YCFGDIALOG_H
#include <QtGui>
#include <QDialog>

class YCfgDialog:public QDialog
{
    Q_OBJECT

public :
    YCfgDialog(QWidget * parent =0);
    void ShowDialog(std::string * y_unit_string , std::string * y_func_str,float * y_max);

    std::string * y_unit_string ;
    std::string * y_func_str;
    float * y_max;

private:
    QLabel *l1,*l2,*l3;
    QLineEdit *unit_str,*func_str,*y_max_in;
    QPushButton *ok,*cancel;

private slots:
    void saveCfg();
};

#endif // YCFGDIALOG_H
