#include "ycfgdialog.h"

YCfgDialog ::YCfgDialog(QWidget * parent):QDialog(parent)
{
    l1 = new QLabel(tr("<p><font color = blue>Y scale</font> (i.e volt/div) <font color = blue>:</font></p>"));
    l2 = new QLabel(tr("<p><font color = blue>Function</font><br>(use small x for voltage i.e 2*x-(x^0.5)) <font color = blue>:</font></p>"));
    l3 = new QLabel(tr("<p><font color = blue>Maximum value for y axis :</font></p>"));

    unit_str = new QLineEdit("");
    func_str = new QLineEdit("");
    y_max_in = new QLineEdit("");

    ok = new QPushButton("Ok");
    cancel = new QPushButton("Cancel");


    QVBoxLayout * left = new QVBoxLayout;
    left->addWidget(l1);
    left->addWidget(l2);
    left->addWidget(l3);
    left->addWidget(ok);

    QVBoxLayout * right = new QVBoxLayout;
    right->addWidget(unit_str);
    right->addWidget(func_str);
    right->addWidget(y_max_in);
    right->addWidget(cancel);

    QHBoxLayout * mL = new QHBoxLayout;
    mL->addLayout(left);
    mL->addLayout(right);

    setLayout(mL);

    this->setFixedSize(350,123);

    connect(cancel,
            SIGNAL(clicked()),
            this,
            SLOT(close()));
    connect(ok,
            SIGNAL(clicked()),
            this,
            SLOT(saveCfg()));
}


void YCfgDialog :: ShowDialog(std::string * y_unit_string , std::string * y_func_str,float * y_max)
{
    this->y_unit_string = y_unit_string;
    this->y_func_str = y_func_str;
    this->y_max = y_max;

    unit_str->setText(QString::fromStdString(*y_unit_string));
    func_str->setText(QString::fromStdString(*y_func_str));
    y_max_in->setText(QString::number(*y_max));

    this->show();
}


void YCfgDialog::saveCfg()
{
    if(unit_str->text()!=NULL &&
            func_str->text()!=NULL &&
            y_max_in->text()!= NULL)
    {
        QFile file("cfg/y_func.cfg");
        if(!file.open(QIODevice::ReadWrite))
        {
            QMessageBox::warning(this,"Error ","Could not open the configuration file\nPlease restart the program with admin priviledge");
            this->close();
        }
        else
        {
            *y_unit_string = unit_str->text().toStdString();
            QString tmp = func_str->text();
            tmp.simplified();
            tmp.replace(" ","");
            *y_func_str = tmp.toStdString();
            *y_max = y_max_in->text().toFloat();

            QString str ;
            str+=(unit_str->text()+"\n");
            str+=(tmp+"\n");
            str+=( y_max_in->text()+"\n");

            file.resize(0);
            file.write((const char*)str.toAscii().data());

            QMessageBox::about(this,"Done","Configurations saved\n\nPlease Stop any running action then restart them");
            this->close();
        }
    }
    else
    {
        QMessageBox::warning(this,"Error ","Did you forget to set all the values ?");
        this->close();
    }
}
