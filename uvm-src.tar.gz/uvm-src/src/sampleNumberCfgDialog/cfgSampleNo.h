#ifndef CFGSAMPLENO_H
#define CFGSAMPLENO_H

#include <QtGui>

class CfgSampleNo : public QDialog
{
    Q_OBJECT

public:
    CfgSampleNo(QWidget * parent =0);
    void ShowDialog(int * samplesToTake,int * sampleTimeInterval);

    int * samplesToTake;
    int * sampleTimeInterval;

private:
    QLabel * l1,*l2;
    QLineEdit * input,*timeInterval;

    QPushButton * ok,*cancel;

private slots:
    void save();
};

#endif // CFGSAMPLENO_H
