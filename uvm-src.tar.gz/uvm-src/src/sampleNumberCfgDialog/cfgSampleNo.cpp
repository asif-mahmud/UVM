#include "cfgSampleNo.h"

CfgSampleNo::CfgSampleNo(QWidget *parent):QDialog(parent)
{
    l1= new QLabel("Samples to take : ");
    l2 = new QLabel("Time Interval :");
    input = new QLineEdit("");
    timeInterval = new QLineEdit("100");
    timeInterval->setReadOnly(true);
    timeInterval->setEnabled(false);

    ok = new QPushButton("Ok");
    cancel = new QPushButton("Cancel");

    QVBoxLayout * left = new QVBoxLayout;
    left->addWidget(l1);
    left->addWidget(l2);
    left->addWidget(ok);

    QVBoxLayout * right = new QVBoxLayout;
    right->addWidget(input);
    right->addWidget(timeInterval);
    right->addWidget(cancel);


    QHBoxLayout * mL = new QHBoxLayout;
    mL->addLayout(left);
    mL->addLayout(right);

    setLayout(mL);

    setFixedSize(200,96);

    connect(cancel,
            SIGNAL(clicked()),
            this,
            SLOT(close()));
    connect(ok,
            SIGNAL(clicked()),
            this,
            SLOT(save()));
}


void CfgSampleNo::ShowDialog(int *samplesToTake, int *sampleTimeInterval)
{
    this->samplesToTake = samplesToTake;
    this->sampleTimeInterval = sampleTimeInterval;
    input->setText(QString::number(*this->samplesToTake));
    timeInterval->setText(QString::number(*this->sampleTimeInterval));
    this->show();
}


void CfgSampleNo::save()
{
    if(input->text()!= NULL &&
            timeInterval->text()!=NULL)
    {


        QFile file("cfg/smpl.cfg");
        if(!file.open(QIODevice::ReadWrite))
        {
            QMessageBox::warning(this,"Error ","Could not open the configuration file\nPlease restart the program with admin priviledge");
            this->close();
        }
        else
        {
            *samplesToTake = input->text().toInt();
            *sampleTimeInterval = timeInterval->text().toInt();

            QString str ;
            str+=(QString::number(*samplesToTake)+"\n");
            str+=(QString::number(*sampleTimeInterval)+"\n");
            file.resize(0);
            file.write((const char*)str.toAscii().data());
            file.close();

            QMessageBox::about(this,"Done","Configurations saved\n\nPlease Stop any running action then restart them");
            this->close();
        }
    }
    else
    {
        QMessageBox::warning(this,"Error ","Did you forget to set all the values ?");
        this->close();
    }
}
