

//------------LED definitions--------//
#define LED_DDR    		DDRD
#define LED_PORT     	PORTD
#define LED_BUSY 		2
#define LED_SLEEPING	1
//-----------------------------------//

//---------LOAD definitions-----------//
#define LOAD_DDR		DDRD
#define LOAD_PORT	    PORTD
#define LOAD_PORT_NO	7
unsigned char monitorLoad = 0;
unsigned char startValue = 0;
unsigned char stopValue = 0;
//------------------------------------//


//------------Include files----------//
#include <avr/io.h>
#include <avr/wdt.h>
#include <avr/interrupt.h>  /* for sei() */
#include <util/delay.h>     /* for _delay_ms() */

#include <avr/pgmspace.h>   /* required by usbdrv.h */
#include "usbdrv.h"
#include "oddebug.h"        /* This is also an example for using debug macros */
#include "requests.h"       /* The custom request numbers we use */


#include "ADC_Header/adc.h"
//-----------------------------------//


/* ------------------------------------------------------------------------- */
/* ----------------------------- USB interface ----------------------------- */
/* ------------------------------------------------------------------------- */

usbMsgLen_t usbFunctionSetup(uchar data[8])
{
	//LED_PORT = LED_BUSY;
	usbRequest_t    *rq = (void *)data;
	static uchar    dataBuffer[1];  /* buffer must stay valid when usbFunctionSetup returns */
	//static uchar	test[4];
	uint8_t Data ;
	//unsigned test_t;
	if(rq->bRequest == CUSTOM_RQ_ECHO)/*this is for test*/
	{									/*if it is */
		
		return 0;
	}
	else if(rq->bRequest == CUSTOM_RQ_GET_STATUS)/*this request will be called */
	{											/*to read and set the adc value*/
												/*this will do that */
		
		LED_PORT |= LED_BUSY;								/*and will return that value*/
		Data = read_adc(1);/*From channel 1*/	/*immediately*/
		
		if(monitorLoad)//load controlling logic
		{
			if(Data<=startValue)
				LOAD_PORT |= (1<<LOAD_PORT_NO);
			else if(Data >stopValue)
				LOAD_PORT &= (~(1<<LOAD_PORT_NO));
		}

		
		dataBuffer[0] = Data;


		
		usbMsgPtr = dataBuffer;
		
		LED_PORT |= LED_SLEEPING;
		LED_PORT &= (~(LED_BUSY));
		
		return 1;
	}								
	else if(rq->bRequest == CUSTOM_RQ_SET_STATUS)/*set load controlling status*/
	{
		LOAD_PORT |= (1<<LOAD_PORT_NO);
		if(rq->wIndex.bytes[0])//it holds whether in monitoring mode or not here yes
		{
			monitorLoad = 1;
			startValue = rq->wValue.bytes[0];
			stopValue = rq->wValue.bytes[1];
		}
		else	//here dont monitor
		{
			monitorLoad = 0;
			startValue = 0;
			stopValue = 0;
		}
	}
	


    return 0;   /* default for not implemented requests: return no data back to host */
}

/* ------------------------------------------------------------------------- */

int __attribute__((noreturn)) main(void)
{
	uchar   i;
	
	//--priliminary works-------//
	LED_DDR = 0b11100011;
	
	//LOAD_PORT = 0b00000001;
	init_adc();
	LED_PORT = LED_SLEEPING;
	//DDRB = 0b0001100;
	
	//--------------------------//
	
	

    wdt_enable(WDTO_1S);


    odDebugInit();
    DBG1(0x00, 0, 0);       /* debug output: main starts */
    usbInit();
    usbDeviceDisconnect();  /* enforce re-enumeration, do this while interrupts are disabled! */
    i = 0;
    while(--i){             /* fake USB disconnect for > 250 ms */
        wdt_reset();
        _delay_ms(1);
    }
    usbDeviceConnect();

    sei();
    DBG1(0x01, 0, 0);       /* debug output: main loop starts */
    for(;;){                /* main event loop */
        DBG1(0x02, 0, 0);   /* debug output: main loop iterates */
        wdt_reset();
        usbPoll();
    }
}

/* ------------------------------------------------------------------------- */

