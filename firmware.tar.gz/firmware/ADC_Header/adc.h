#ifndef __ADC_H_INCLUDED__
#define __ADC_H_INCLUDED__

#include <avr/io.h>
#include <stdint.h>

void init_adc()
{
	ADMUX = (1<<ADLAR)|(1<<REFS1)|(1<<REFS0);//internal ~2.56 V ref found 2.49 V
	ADCSRA= (1<<ADEN)|(1<<ADPS2)|(1<<ADPS1)|(1<<ADPS0);//Prescaler div factor = 128
}

uint8_t read_adc(uint8_t channel)
{
	//first select ADC chanel to work with
	channel = channel&0b00000111;
	ADMUX|=channel;
	
	//now start a single conversion
	ADCSRA |= (1<<ADSC);
	
	//Wait till the conversion completes
	while(!(ADCSRA & (1<<ADIF)));
	
	//now Clear ADIF bit
	//wath it on datasheet
	ADCSRA |= (1<<ADIF);
	
	return ADCH;
}

#endif
